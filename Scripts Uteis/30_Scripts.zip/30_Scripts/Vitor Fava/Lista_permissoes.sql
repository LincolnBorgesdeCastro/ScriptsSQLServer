SELECT * FROM sys.fn_builtin_permissions(DEFAULT) 
    WHERE permission_name = 'SELECT';
